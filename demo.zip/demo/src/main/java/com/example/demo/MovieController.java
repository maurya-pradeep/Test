package com.example.demo;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;

@RestController
@RequestMapping("/")
public class MovieController {

	@Autowired
	private MovieService movieService;

	@RequestMapping(value = "/get/movie", method = RequestMethod.POST)
	public Map<String, Object> getMovie(@RequestBody JsonNode node) throws Exception {

		Map<String, Object> map = movieService.getMovie(node);
		return map;
	}
}
