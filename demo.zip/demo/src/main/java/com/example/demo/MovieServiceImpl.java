package com.example.demo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.databind.JsonNode;;

@Service
public class MovieServiceImpl implements MovieService {

	@Autowired
	private MovieRepository movieRepository;

	public Map<String, Object> getMovie(JsonNode node) throws Exception {
		Map<String, Object> response = new HashMap<String, Object>();
		int previousPage = 0;
		int pageSize = node.get("pageSize") != null ? node.get("pageSize").asInt() : 10;
		int totalRecord = 0;
		int offset = 0;
		int maxPage = 0;
		List<Movie> movieList = null;
		try {
			int pageNo = node.get("pageNo").asInt();
			int type = node.get("type").asInt();
			String search = node.get("search").asText();

			if (type == 1) { // getAll
				totalRecord = movieRepository.getMovieCount();
				maxPage = (totalRecord + pageSize - 1) / pageSize;
				previousPage = pageNo - 1;
				offset = (pageNo - 1) * pageSize;
				movieList = movieRepository.getMovieData(offset, pageSize);
			}
			if (type == 2) { // search
				if (!search.isEmpty()) {
					totalRecord = movieRepository.getMovieSearchCount(search);
					maxPage = (totalRecord + pageSize - 1) / pageSize;
					previousPage = pageNo - 1;
					offset = (pageNo - 1) * pageSize;
					movieList = movieRepository.getMovieSearchSearchData(offset, pageSize, search);
				}
			}

			if (CollectionUtils.isEmpty(movieList)) {
				response.put("data", movieList);
				response.put("totalRecord", totalRecord);
			}
		} catch (Exception ex) {
			throw ex;
		}
		return response;
	}

	
}
