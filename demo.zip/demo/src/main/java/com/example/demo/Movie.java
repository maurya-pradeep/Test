package com.example.demo;

public class Movie {
	
	private int id;
	private String movieName;
	private int yearOfRelease;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public int getYearOfRelease() {
		return yearOfRelease;
	}
	public void setYearOfRelease(int yearOfRelease) {
		this.yearOfRelease = yearOfRelease;
	}
	
	@Override
	public String toString() {
		return "Movie [id=" + id + ", movieName=" + movieName + ", yearOfRelease=" + yearOfRelease + "]";
	}
	
	

}
