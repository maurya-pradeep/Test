package com.example.demo;

import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;

public interface MovieService {

	Map<String, Object> getMovie(JsonNode node) throws Exception;

}