package com.example.demo;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface MovieRepository {

	@Select("select count(*) from Movie")
	int getMovieCount();

	@Select("select * from Movie OFFSET #{offset} ROWS FETCH NEXT #{pageSize} ROWS ONLY")
	public List<Movie> getMovieData(@Param("offset") int offset, @Param("pageSize") int pageSize);

	@Select("SELECT coun(*) FROM Movie m WHERE m.movieName LIKE %#{searchQuery}%")
	int getMovieSearchCount(@Param(value = "searchQuery") String searchQuery);

	@Select("SELECT p FROM Movie m WHERE m.movieName LIKE %#{searchQuery}%"
			+ " OFFSET #{offset} ROWS FETCH NEXT #{pageSize} ROWS ONLY")
	List<Movie> getMovieSearchSearchData(@Param(value = "offset") int offset, @Param(value = "pageSize") int pageSize,
			@Param(value = "searchQuery") String searchQuery);

}